package ir.kingnet.app

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wireguard.android.backend.Backend
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import java.io.ByteArrayInputStream
import java.util.concurrent.Executors

private val Black = Color(0xFF090909)
private val Card = Color(0xFF151515)
private val Gold = Color(0xFFD9A441)
private val Muted = Color(0xFF9A9A9A)

data class TunnelProfile(
    val name: String,
    val config: String,
    val address: String = "WireGuard"
)

class MainActivity : ComponentActivity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var backend: Backend
    private var pendingConnect = false
    private var connectCallback: (() -> Unit)? = null

    private val vpnPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && pendingConnect) {
                pendingConnect = false
                connectCallback?.invoke()
            } else {
                pendingConnect = false
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        backend = GoBackend(applicationContext)

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = Black,
                    surface = Card,
                    primary = Gold,
                    onPrimary = Black
                )
            ) {
                KingNetScreen(
                    onConnect = { profile, onResult ->
                        connectProfile(profile, onResult)
                    },
                    onDisconnect = { profile, onResult ->
                        disconnectProfile(profile, onResult)
                    }
                )
            }
        }
    }

    private fun connectProfile(profile: TunnelProfile, onResult: (Boolean, String) -> Unit) {
        val permissionIntent = VpnService.prepare(this)
        connectCallback = {
            executor.execute {
                try {
                    val config = Config.parse(
                        ByteArrayInputStream(profile.config.toByteArray(Charsets.UTF_8))
                    )
                    val tunnel = AppTunnel(profile.name) { state ->
                        runOnUiThread {
                            if (state == Tunnel.State.UP) onResult(true, "Connected")
                            if (state == Tunnel.State.DOWN) onResult(false, "Disconnected")
                        }
                    }
                    backend.setState(tunnel, Tunnel.State.UP, config)
                    runOnUiThread { onResult(true, "Connected") }
                } catch (e: Exception) {
                    runOnUiThread {
                        onResult(false, e.message ?: "Connection failed")
                    }
                }
            }
        }

        if (permissionIntent != null) {
            pendingConnect = true
            vpnPermissionLauncher.launch(permissionIntent)
        } else {
            pendingConnect = false
            connectCallback?.invoke()
        }
    }

    private fun disconnectProfile(profile: TunnelProfile, onResult: (Boolean, String) -> Unit) {
        executor.execute {
            try {
                val config = Config.parse(
                    ByteArrayInputStream(profile.config.toByteArray(Charsets.UTF_8))
                )
                val tunnel = AppTunnel(profile.name) {}
                backend.setState(tunnel, Tunnel.State.DOWN, config)
                runOnUiThread { onResult(false, "Disconnected") }
            } catch (e: Exception) {
                runOnUiThread { onResult(false, e.message ?: "Disconnect failed") }
            }
        }
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}

private class AppTunnel(
    private val tunnelName: String,
    private val listener: (Tunnel.State) -> Unit
) : Tunnel {
    override fun getName(): String = tunnelName
    override fun onStateChange(newState: Tunnel.State) {
        listener(newState)
    }
}

@Composable
private fun KingNetScreen(
    onConnect: (TunnelProfile, (Boolean, String) -> Unit) -> Unit,
    onDisconnect: (TunnelProfile, (Boolean, String) -> Unit) -> Unit
) {
    var profiles by remember { mutableStateOf(listOf<TunnelProfile>()) }
    var selected by remember { mutableStateOf<TunnelProfile?>(null) }
    var connected by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("No tunnel imported") }
    var busy by remember { mutableStateOf(false) }

    val filePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            // The actual file read is intentionally kept in the UI layer simple.
            // ContentResolver is available through LocalContext if extended.
        }
    }

    Surface(Modifier.fillMaxSize(), color = Black) {
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            Text("KINGNET", color = Gold, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            Text("Real WireGuard Client", color = Muted, fontSize = 13.sp)

            Spacer(Modifier.height(24.dp))

            Card(
                Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Card),
                shape = RoundedCornerShape(22.dp)
            ) {
                Column(
                    Modifier.padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        Modifier.size(118.dp).background(
                            if (connected) Gold else Color(0xFF222222), CircleShape
                        ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            if (connected) "ON" else "OFF",
                            color = if (connected) Black else Color.White,
                            fontSize = 25.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(Modifier.height(14.dp))
                    Text(status, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(16.dp))

                    Button(
                        enabled = selected != null && !busy,
                        onClick = {
                            val p = selected ?: return@Button
                            busy = true
                            if (!connected) {
                                onConnect(p) { ok, msg ->
                                    connected = ok
                                    status = msg
                                    busy = false
                                }
                            } else {
                                onDisconnect(p) { ok, msg ->
                                    connected = ok
                                    status = msg
                                    busy = false
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Gold,
                            contentColor = Black
                        )
                    ) {
                        Text(if (connected) "DISCONNECT" else "CONNECT", fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(Modifier.height(22.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("My Tunnels", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                OutlinedButton(onClick = { /* import flow can be expanded */ }) {
                    Text("+ Add")
                }
            }

            Spacer(Modifier.height(10.dp))

            if (profiles.isEmpty()) {
                Text(
                    "Import a WireGuard .conf profile to begin.",
                    color = Muted,
                    modifier = Modifier.padding(vertical = 20.dp)
                )
            }

            Spacer(Modifier.height(14.dp))
            Text(
                "Powered by KingNet",
                color = Gold,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.fillMaxWidth()
            )

            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(profiles) { profile ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Card),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            Modifier.fillMaxWidth().padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(profile.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                                Text(profile.address, color = Muted, fontSize = 12.sp)
                            }
                            Text("›", color = Gold, fontSize = 28.sp)
                        }
                    }
                }
            }
        }
    }
}
