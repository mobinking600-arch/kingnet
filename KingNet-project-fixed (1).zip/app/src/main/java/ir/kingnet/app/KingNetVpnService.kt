package ir.kingnet.app

import android.content.Intent
import android.net.VpnService
import android.os.IBinder

/**
 * KingNet VPN service placeholder.
 *
 * IMPORTANT:
 * This class establishes the Android VPN service entry point only.
 * A production WireGuard client must integrate a WireGuard backend
 * and configure the tunnel interface from a validated WireGuard profile.
 */
class KingNetVpnService : VpnService() {
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Backend integration goes here.
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? {
        return super.onBind(intent)
    }
}
